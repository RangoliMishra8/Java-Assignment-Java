package opps;

public class A4 {
	public static void main(String[] args) {
		Employee employee=new
				CommisionEmployee(121, "amit", 2.1, 2000000);
		System.out.println(employee.getPayment());

} 
	}
