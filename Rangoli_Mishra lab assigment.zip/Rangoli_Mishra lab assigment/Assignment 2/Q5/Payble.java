package opps;

public interface Payble {
	abstract public double getPayment();
}