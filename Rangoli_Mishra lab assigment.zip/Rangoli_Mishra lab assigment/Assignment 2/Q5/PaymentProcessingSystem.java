package opps;

public class PaymentProcessingSystem {
	public static void processPayment(Payble payable) {
		
		System.out.println("payment of total: "+ payable.getPayment()+" is processed");
	}

}
