package a;

public class A2 {
	
	

	public static void main(String[] args) {
		Bookstore bookStore=new Bookstore("harman", 5);
		bookStore.sell("spring in action", 2);
		bookStore.display();
	}
}
