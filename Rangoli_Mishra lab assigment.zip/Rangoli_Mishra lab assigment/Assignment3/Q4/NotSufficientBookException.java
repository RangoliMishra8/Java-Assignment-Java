package a3;

public class NotSufficientBookException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
